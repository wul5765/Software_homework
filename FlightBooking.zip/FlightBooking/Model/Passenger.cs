﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlightBooking.Model
{
    public class Passenger
    {
        public string Name { get; set; }
        public string Number { get; set; }  
        public bool IsVip { get; set; }
    }
}
